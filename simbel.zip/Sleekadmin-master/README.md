# Sleekadmin Bootstrap 4 Template
Bootstrap 4, CSS 3, HTML 5, Material Design Admin dashboard template

### [View live demo](http://sleekadmin.surge.sh/Sleek/index.html)

# Preview

![Sleekadmin dashboard template preview](http://sleekadmin.surge.sh/img/heroImage.png)

# Overview
Sleekadmin is a full-featured, multipurpose, premium bootstrap admin template built with Bootstrap 4 Framework, HTML5, CSS and JQuery.

It is a fully responsive bootstrap admin dashboard template that comes with a huge collection of reusable UI components & plugins.

# Template Features:

- 4 Deferent Home Version
- Based on Bootstrap 4
- HTML5, CSS3, jQuery
- Fontawesome Icons
- Clean UI Elements
- Ecommerce friendly
- Vector maps
- JSGrid & Datatables


### Changelog 
#### V 1.0.0
Initial Release

### Author
Code resource [Techadam]


