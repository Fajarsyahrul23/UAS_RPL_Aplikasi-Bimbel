-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 24 Mei 2023 pada 08.15
-- Versi Server: 5.5.32
-- Versi PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `db_simbel`
--
CREATE DATABASE IF NOT EXISTS `db_simbel` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_simbel`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE IF NOT EXISTS `guru` (
  `id` varchar(250) NOT NULL,
  `id_user` varchar(256) NOT NULL,
  `nama_guru` varchar(256) NOT NULL,
  `jekel` varchar(20) NOT NULL,
  `alamat` varchar(256) NOT NULL,
  `telp` varchar(256) NOT NULL,
  `temp` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `temp` (`temp`),
  UNIQUE KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id`, `id_user`, `nama_guru`, `jekel`, `alamat`, `telp`, `temp`) VALUES
('G-001', 'U-004', 'Indra Jaya', 'L', 'Jl.Rimbo Data Rt.03 Rw.01, Kelurahan Banda Buek, Kecamatan Lubuk Kilangan, Padang', '08323238833', 1),
('G-002', 'U-005', 'hendra., S,PD', 'L', 'Jl.Rimbo Data Rt.03 Rw.01, Kelurahan Banda Buek, Kecamatan Lubuk Kilangan, Padang', '08323238833', 2),
('G-004', 'U-009', 'syahrul', 'L', 'purwakarta', '087737968838', 6);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mapel` int(11) NOT NULL,
  `id_guru` varchar(100) NOT NULL,
  `id_jenis_program` int(11) NOT NULL,
  `hari` varchar(200) NOT NULL,
  `jam` time NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`id`, `id_mapel`, `id_guru`, `id_jenis_program`, `hari`, `jam`, `keterangan`) VALUES
(14, 1, 'G-001', 3, 'senin', '17:00:00', '-'),
(15, 2, 'G-002', 3, 'selasa', '17:00:00', '-'),
(16, 3, 'G-004', 1, 'senin', '16:00:00', ''),
(17, 3, 'G-002', 2, 'kamis', '15:38:00', 'Dilakukan secara Online'),
(18, 1, 'G-004', 2, 'rabu', '16:38:00', 'Dilakukan secara Online');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_program`
--

CREATE TABLE IF NOT EXISTS `jenis_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_program` int(11) NOT NULL,
  `harga` double NOT NULL,
  `kuota` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `jenis_program`
--

INSERT INTO `jenis_program` (`id`, `id_program`, `harga`, `kuota`) VALUES
(1, 1, 350000, 20),
(2, 2, 450000, 10),
(3, 3, 600000, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mapel`
--

CREATE TABLE IF NOT EXISTS `mapel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_mapel` varchar(256) NOT NULL,
  `keterangan` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `mapel`
--

INSERT INTO `mapel` (`id`, `nama_mapel`, `keterangan`) VALUES
(1, 'matematika', ''),
(2, 'bahasa inggris', ''),
(3, 'bahasa indonesia', ''),
(4, 'IPA', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `id` varchar(100) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `tgl_bayar` date NOT NULL,
  `jumlah_bayar` double NOT NULL,
  `jenis_pembayaran` varchar(250) NOT NULL,
  `bukti` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `temp` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `temp` (`temp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `id_pendaftaran`, `tgl_bayar`, `jumlah_bayar`, `jenis_pembayaran`, `bukti`, `status`, `keterangan`, `temp`) VALUES
('PBY2981', 1, '2121-02-17', 600000, '', 'sat1.jpg', 2, '', 1),
('PBY2982', 2, '2121-02-22', 600000, '', 'SATRIA-RAHMAT-PUTRA1-removebg-preview.png', 2, '', 2),
('PBY2983', 3, '2023-04-23', 350000, '', 'byar.jpg', 2, '', 3),
('PBY2985', 5, '2023-04-29', 450000, '', '', 2, '', 5),
('PBY2986', 6, '2023-04-29', 350000, '', '33F96C62-DEB2-4A88-9416-43F94658C23E.png', 2, '', 6),
('PBY2988', 8, '2023-05-16', 600000, '', 'depositphotos_63519645-stock-illustration-cartoon-kids-reading-book-removebg-preview.png', 1, '', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran`
--

CREATE TABLE IF NOT EXISTS `pendaftaran` (
  `id` int(11) NOT NULL,
  `id_jenis_program` int(11) NOT NULL,
  `id_user` varchar(200) NOT NULL,
  `harga` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendaftaran`
--

INSERT INTO `pendaftaran` (`id`, `id_jenis_program`, `id_user`, `harga`, `status`) VALUES
(1, 3, 'U-002', 600000, 1),
(2, 3, 'U-003', 600000, 1),
(3, 1, 'U-0010', 350000, 1),
(5, 2, 'U-0012', 450000, 1),
(6, 1, 'U-0013', 350000, 1),
(8, 3, 'U-0015', 600000, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id` varchar(200) NOT NULL,
  `id_user` varchar(100) NOT NULL,
  `nama` varchar(256) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `tempat_lahir` varchar(200) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `sekolah` varchar(256) NOT NULL,
  `nama_ortu` varchar(100) NOT NULL,
  `pekerjaan_ortu` varchar(250) NOT NULL,
  `alamat` text NOT NULL,
  `temp` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `temp` (`temp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `id_user`, `nama`, `kelas`, `jenis_kelamin`, `tempat_lahir`, `tgl_lahir`, `sekolah`, `nama_ortu`, `pekerjaan_ortu`, `alamat`, `temp`) VALUES
('S-001', 'U-002', 'Satria Rahmat Putra', '3', 'L', 'padang', '2021-02-08', 'SMP N 11 PADANG', 'Nur', 'swasta', 'Jl.Rimbo Data Rt.03 Rw.01, Kelurahan Banda Buek, Kecamatan Lubuk Kilangan, Padang', 1),
('S-002', 'U-003', 'hexa', '3', 'P', 'Payakumbuh', '2021-02-22', 'SMP N 11 PADANG', 'Nur', '-', 'Jl.Rimbo Data Rt.03 Rw.01, Kelurahan Banda Buek, Kecamatan Lubuk Kilangan, Padang', 2),
('S-003', 'U-0010', 'fajar syahrul hidayat', '12', 'L', 'Purwakarta', '2002-12-20', 'smkn 1 sukatani', '-', '-', 'purwakarta', 3),
('S-004', 'U-0012', 'habil', '4A Sistem Informasi', 'L', 'karawang', '2002-12-17', 'UNSIKA', '-', '-', 'klari Karawang', 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa_pendaftaran`
--

CREATE TABLE IF NOT EXISTS `siswa_pendaftaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_siswa` varchar(200) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `keterangan` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data untuk tabel `siswa_pendaftaran`
--

INSERT INTO `siswa_pendaftaran` (`id`, `id_siswa`, `id_pendaftaran`, `status`, `keterangan`) VALUES
(5, 'S-001', 1, 1, 'lunas'),
(7, 'S-002', 2, 1, 'lunas'),
(8, 'S-003', 3, 1, 'lunas'),
(9, 'S-004', 5, 1, 'lunas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_program`
--

CREATE TABLE IF NOT EXISTS `tb_program` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_program` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `tb_program`
--

INSERT INTO `tb_program` (`id`, `nama_program`) VALUES
(1, 'Low'),
(2, 'VIP'),
(3, 'VVIP');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(100) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `no_telp` varchar(200) NOT NULL,
  `image` varchar(150) NOT NULL,
  `password` varchar(260) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL,
  `temp` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`temp`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `no_telp`, `image`, `password`, `role_id`, `is_active`, `date_created`, `temp`) VALUES
('0', 'admin', 'admin@gmail.com', '', 'default.png', '$2y$10$hWI2gkMUd9sX06bgXu6QIO7GPIlqUHEeMAd3AC5qqXCIX7N5qv.AS', 1, 1, 1601653500, 1),
('U-002', 'Satria Rahmat Putra', 'satriarahmatputra@gmail.com', '08323238833', 'default.png', '$2y$10$n1hr70uFOPx9fEGHf5qc4eSfMOT8rHEfGDhl7vDkaZxqUmtNMFMdO', 2, 1, 1613550185, 2),
('U-003', 'hexa', 'hexa@gmail.com', '08323238833', 'default.png', '$2y$10$d.RDLGYlVnps7oc1RqUJu.eeuqwmOTR/vLCbZf.bGYU6Lzvz0kH2u', 2, 1, 1614009384, 3),
('U-004', 'Indra Jaya', 'indrajaya@gmail.com', '', 'default.png', '$2y$10$zDlS9C.Ykb4kRD2C49OnneGQepD/V4XPU2iE3BRPitKGeD6FomYvu', 3, 1, 1614010248, 4),
('U-005', 'hendra., S,PD', 'hendra@gmail.com', '', 'default.png', '$2y$10$hUb3vYJ17.YuyeizgqWZf.5jWIugjqRjA89yi8bGH4Le4R0aOYH/W', 3, 1, 1614010267, 5),
('U-009', 'syahrul', 'syahrul@gmail.com', '', 'default.png', '$2y$10$tQYkP2U9lvRGCWWDE0dFeOUSNU/gieRzL6dTK9LbOK7PDAqh.SiyK', 3, 1, 1682222879, 9),
('U-0010', 'fajar syahrul hidayat', 'fajar@gmail.com', '087737968888', 'default.png', '$2y$10$Iq5CscLG0jNXdYtTk4d6geIGK7Tl/GwbLhSyC0Pj5mopFRm8Y929u', 2, 1, 1682223096, 10),
('U-0012', 'habil', 'habil@gmail.com', '123456780', 'default.png', '$2y$10$vyyifK51w2L5PM.p2.q9eeTl1g7myJzzuAxId63QDLXh9xItg.dSi', 2, 1, 1682781142, 12),
('U-0013', 'dimas', 'dimas@gmail.com', '12345678', 'default.png', '$2y$10$18kiPhckiWa36Q9sa59rIeBqAA0snTa5f7i0u0tDbskbOOwlldULG', 2, 1, 1682783006, 13),
('U-0015', 'testing1', 'testing1@gmail.com', '12345676543', 'default.png', '$2y$10$uVgCbWPdUTThP8BKSewZg.z6bIviChC/5I8d2CapajQ7cq47ZhHAm', 2, 0, 1684217325, 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE IF NOT EXISTS `user_access_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(12, 1, 1),
(13, 1, 2),
(14, 1, 3),
(16, 2, 5),
(17, 2, 4),
(18, 1, 6),
(19, 2, 7),
(20, 3, 11),
(21, 1, 9),
(22, 3, 10),
(23, 2, 12),
(24, 3, 13);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE IF NOT EXISTS `user_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(120) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Dashboard'),
(2, 'Program'),
(3, 'Konfirmasi'),
(4, 'Dashboard'),
(5, 'Bodata'),
(6, 'jadwal'),
(7, 'Jadwal'),
(9, 'Data'),
(10, 'Dashboard'),
(11, 'Jadwal'),
(12, 'Akun'),
(13, 'Akun');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(130) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'admin'),
(2, 'siswa'),
(3, 'guru');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE IF NOT EXISTS `user_sub_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(120) NOT NULL,
  `url` varchar(120) NOT NULL,
  `icon` varchar(120) NOT NULL,
  `is_active` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(17, 1, 'Dashboard', 'Admin', 'fas fa-fw fa-user-circle', 1),
(18, 1, 'pegawai', 'Pegawai', 'fas fa-fw fa-user-circle', 0),
(19, 2, 'Program', 'Program', '', 1),
(20, 2, 'Jenis Program', 'Program/index_JP', '', 1),
(23, 3, 'Konfirmasi Siswa', 'Konfirmasi/siswa', '', 1),
(24, 5, 'Data Diri', 'datadiri', '', 1),
(25, 4, 'Dashboard', 'siswa', '', 1),
(26, 6, 'Kelola jadwal', 'jadwal', '', 1),
(27, 3, 'Konfirmasi Guru', 'konfirmasi/guru', '', 1),
(28, 7, 'jadwal ku', 'siswa/jadwal', '', 1),
(29, 11, 'Mengajar', 'guru/jadwal', '', 1),
(30, 9, 'Guru', 'data', '', 1),
(31, 9, 'siswa', 'data/siswa', '', 1),
(32, 10, 'Dashboard', 'guru', '', 1),
(33, 12, 'Ganti Password', 'siswa/ganti_pass', '', 1),
(34, 13, 'Ganti Password', 'guru/ganti-password', '', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
